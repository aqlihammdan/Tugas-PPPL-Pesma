<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Laporan extends Model
{
    use HasFactory;

    protected $table = "Laporan";
    protected $primarykey =['id'];
    protected $fillable =['id','name', 'tanggalpembayaran', 'Lembaga', 'jumlah_pembayaran','bulanbayar','file_bukti'];
    protected $casts = ['tanggalpembayaran'=>'date'];
}
